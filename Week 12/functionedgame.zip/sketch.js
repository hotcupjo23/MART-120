// character x & y
var characterX = 100;
var characterY = 100;


//key codes
var w = 87;
var s = 83;
var a = 65;
var d = 68;

// shape x & y
var shapeX = 0;
var shapeY = 50;
var shapeX2 = 100
var shapeY2 = 250
var shapeXSpeed;
var shapeYSpeed;

// mouse click vars
var mouseShapeX;
var mouseShapeY;
function setup ()
{
  createCanvas(800, 700);
  // random speeds for start
  shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random()*3)) +1);
  shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random()*3)) +1);
  shapeX2Speed = Math.floor(Math.random() * (Math.floor(Math.random()*5)) +1);
  shapeY2Speed = Math.floor(Math.random() * (Math.floor(Math.random()*5)) +1);
}

function draw ()
{
  background(250, 95, 150);
  stroke(0);
  fill(0);
  
  //top
  rect (0,0,width,10);
  // left
  rect(0,0,10,height);
  // bottom
  rect (0, height-10,width-70,10);
  //right
  rect(width-10,0,10,height)
  
  //winning game
  textSize(20)
  text("ESCAPE!",width-100, height-20)
  
  //hero circle
  fill (0)
  circle (characterX, characterY, 25)
  
  //character key movements
if (keyIsDown(w))
  {
    characterY -=10;
  }
   if (keyIsDown(s))
    {
      characterY +=10;
    }
  
   if (keyIsDown(a))
    {
      characterX -=10;
    }
  
   if (keyIsDown(d))
    {
      characterX +=10;
    }
  //enemy squares
  fill(225,50,50)
  square (shapeX,shapeY,25)
  fill (0,225,50)
  square (shapeX2,shapeY2,25)
  
  //shape movement
  shapeX += shapeXSpeed;
  shapeY += shapeYSpeed;
  shapeX2 += shapeX2Speed;
  shapeY2 += shapeY2Speed;
  
  //out of bounds red square
  if (shapeX > width)
    {
      shapeX = 0;
    }
  if (shapeX < 0)
    {
      shapeX = width;
    }
  if (shapeY > height) {
    shapeY = 0;
  }
  if (shapeY < 0) {
    shapeY = height;
  }
  // out of bounds green square
  if (shapeX2 > width)
    {
      shapeX2 = 0;
    }
  if (shapeX2 < 0)
    {
      shapeX2 = width
    }
  if (shapeY2 > height){
    shapeY2 = 0;
  }
  if (shapeY2 < 0) {
    shapeY2 = height
  }
  
  //winning the game
  if(characterX > width-100 && characterY > width-70)
    {
      fill(0);
      stroke(5);
      textSize(30);
      text("You've Escaped! Congratz!", width/2-50, height/2-50)
    }
  
  
  // brith shapes w/ mouse
  fill(20,60,150)
  circle(mouseShapeX, mouseShapeY, 25)
}

function mouseClicked()
{
  mouseShapeX = mouseX;
  mouseShapeY = mouseY;
}