function setup() {
  createCanvas(500, 600);
}

function draw() {
  background(225, 100, 78);
  fill(210, 180, 140);
  circle(250, 225, 155);
  triangle(265,225,275,225,275,235);
  rect(200, 300, 100, 150);
  fill(225, 225, 225);
  arc(255, 253,40, 40, 50, PI + QUARTER_PI, PIE);
  stroke(126);
  stroke("black");
  strokeWeight(10);
  stroke("black");
  point(285, 195);
  point(245, 210);
  line(200, 450, -500, 3075);
  line(300, 450, 1000, 3075);
  line(300, 300, 400, 75);
  line(200, 300, 300, 25);
  fill(115, 225, 225);
  square(200, 300, 55, 20);
  fill(50, 100, 225);
  square(250, 300, 55, 20);
  fill(15, 5, 125);
  square(250, 350, 55, 20);
  fill(215, 5, 125);
  square(200, 350, 55, 20);
  fill(215, 25, 25);
  square(251, 400, 55, 20);
  fill(15, 215, 125);
  square(200, 400, 55, 20);
  fill(215, 5, 25);
  fill(115, 225, 225);
  textSize(32);
  text("Josiah Kaderis", 250, 30);
}
