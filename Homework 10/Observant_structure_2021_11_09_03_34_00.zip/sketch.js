// background colors
var redColor = 23;
var greenColor = 139;
var blueColor = 121;

// skin and body colors
var headColor = 210;
var headColor2 = 180;
var headColor3 = 140;

// rectangle quards
var xR = 200;
var yR = 300;
var x2R = 100;
var y2R = 150;

// cirlce quards
var x=250;
var y=225;
var diameter=155;


// right arm
var arm1 = 300;
var arm2 = 300;
var arm3 = 400
var arm4 = 75

//left arm
var arm5 = 200;
var arm6 = 300;
var arm7 = 300;
var arm8 = 25;

// teal square
var square1 = 200;
var square2 = 300;
var square3 = 55;
var square4 = 20;

// text size stuff
var a = 32;
var count = 0;
var sizeDirection = 2;

var movement = 2
function setup()
{
    createCanvas(800,600);
  movement = Math.floor(Math.random() * 10) + 1;
  
}
 
function draw() {
  background(redColor, greenColor, blueColor);
  fill(headColor, headColor2, headColor3);
  circle(x, y, diameter);
  if (x>=725 || x <=65) {
    movement *= -1;
  }
  x += movement;
  rect(xR, yR, x2R, y2R);
  if (xR>=725 || xR <=80) {
    movement *= -1;
  }
  xR += movement;
  

  triangle(265,225,275,225,275,235);
  fill(225, 225, 225);
  arc(255, 253,40, 40, 50, PI + QUARTER_PI, PIE);
  stroke(126);
  stroke("black");
  strokeWeight(10);
  stroke("black");
  point(285, 195);
  point(245, 210);
  line(200, 450, -500, 3075);
  line(300, 450, 1000, 3075);
  line(arm1, arm2, arm3, arm4);
  if (y >=725 || y <=65) {
    movement *= -1;
  }
  arm4 += movement;
  
  line(arm5, arm6, arm7, arm8);
  if (y >=725 || y <=65) {
    movement *= -1;
  }
  arm8 += movement;
  
  fill(115, 225, 225);
  square(square1, square2, square3, square4);
  if (x >=725 || x <=65) {
    movement*=-1;
  }
square1 += movement;
  if (y >=725 || y <=165) {
    movement*=-1;
  }
square2 += movement;
  fill(50, 100, 225);
  square(250, 300, 55, 20);
  fill(15, 5, 125);
  square(250, 350, 55, 20);
  fill(215, 5, 125);
  square(200, 350, 55, 20);
  fill(215, 25, 25);
  square(251, 400, 55, 20);
  fill(15, 215, 125);
  square(200, 400, 55, 20);
  fill(215, 5, 25);
  fill(115, 225, 225);
  textSize(a);
  a+= sizeDirection;
  count++;
  if(count > 5)
    {
      sizeDirection *=-1;
      count = 0;
    }
 text("Josiah Kaderis", 250, 30);
}